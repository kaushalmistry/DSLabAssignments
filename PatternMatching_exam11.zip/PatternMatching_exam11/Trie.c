#include <stdio.h>

#define MAX_CHILD 5 //'A', 'T', 'C', 'G', and special character '$'

//Node structure for compressed trie
//You may add other fields depending on your needs.
//You have to justify why the addition of extra fields helps towards efficiency
struct trieNode{
    int startIdx;
    int endIdx;
    
};
struct trieNode children[MAX_CHILD];
typedef struct trieNode trieNode;
typedef struct trieNode *trieNodePtr;



//[5 points] Read text from the file
void readText(char *fileName, char *T)
{

}

//[40 points] Create suffix tree from the text T
void createSuffixTree(trieNodePtr *root, char *T)
{

}

//Find all patterns P in the suffix tree and returns starting positions of the pattern P in array patLocArr
//patLocArrLen denotes the number of times the pattern P appears
//[20 points]
void findAllPatterns(trieNodePtr root, char *P, int *patLocArr, int *patLocArrLen)
{

}

//[10 points]
void displaySuffixTree(trieNodePtr root, char *fileName)
{

}

//[5 points] Prints the number of nodes, total size in main memory of the suffixtree
void statistics(trieNodePtr root)
{

}

int main()
{
    char *T, *P;
    int *patLocArr, patLocArrLen;
    trieNodePtr root = NULL;

    readText("T1.txt", T);
    createSuffixTree(&root, T);

    displaySuffixTree(root, "T1.dot");

    P = "ATCG...";// find this pattern in suffix tree
    findAllPatterns(root, P, patLocArr, &patLocArrLen);

    for (int i = 0; i < patLocArrLen; i++)
        printf("%d ", patLocArr[i]);

    printf("\n");
}
