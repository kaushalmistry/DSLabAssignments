#include <stdio.h>
#include <stdlib.h>
#include <time.h>

struct tnode {
int key, priority;
int left, right;
int parent; //optional
};

typedef struct tnode tnode;

struct Treap {
int root;
int freeList;
tnode *tnodeArr;
int numElements;
};

typedef struct Treap Treap;

//[5 points]
void init(Treap *T, int numElements)
{
    T->tnodeArr = (tnode *)malloc(numElements*sizeof(numElements));
    if (T->tnodeArr == NULL)
        exit(EXIT_FAILURE);

    T->numElements = numElements;

    // Initialize free list here

    T->root = -1;
    T->freeList = 0;
}

// [20 points] -- no duplicate keys
void insertTreap(Treap *T, int key, int priority);
// [20 points]
void deleteTreap(Treap *T, int key);
// [5 points]
int height(Treap *T);
// [10 points]
void displayTreap(Treap *T, char *fileName); //produce dot file
void leftRotate(Treap *T, int node);
void rightRotate(Treap *T, int node);


int main()
{
    srand(time(NULL));

    // Generate a table of tree height for different number of nodes e.g., 100, 1000, 5000, 10000, 50000
}

